# This is a sample Python script.

# Press ⌃R to execute it or replace it with your code.
# Press Double ⇧ to search everywhere for classes, files, tool windows, actions, and settings.


from flask import Flask, render_template, request, redirect, url_for, app
from flask_wtf import Form
from wtforms import TextField
from typing import Dict, List

from google.cloud import aiplatform
from google.cloud import bigquery
from google.protobuf import json_format
from google.protobuf.struct_pb2 import Value
from google.oauth2 import service_account
from google.protobuf.json_format import MessageToDict
from flask_table import Table, Col
import pandas

app = Flask(__name__)



@app.route('/thank-you')
def thank_you(Gender, Country_of_Birth, Marital_Status_Key, Business_Area, Payroll_Area, Position, EducationField
              ,Institution, title):
    instance_dict = {"Gender": Gender, "Country_of_Birth": Country_of_Birth,
                     "Marital_Status_Key": Marital_Status_Key, "Business_Area": Business_Area,
                     "Payroll_Area": Payroll_Area, "Position": Position, "EducationField": EducationField,
                     "Institution": Institution,
                     "title": title}
    #print("Ninad" + instance_dict)
    response = predict_tabular_classification_sample(
        project="5110117733",
        endpoint_id="2198842935645044736",
        location="us-central1",
        instance_dict={"Gender": Gender, "Country_of_Birth": Country_of_Birth,
                       "Marital_Status_Key": Marital_Status_Key, "Business_Area": Business_Area,
                       "Payroll_Area": Payroll_Area, "Position": Position, "EducationField": EducationField,
                       "Institution": Institution,
                       "title": title}
    )

    response_json =MessageToDict(response._pb)
    print(response_json)
    print(response_json["predictions"][0]['value'])
    pred_value = response_json["predictions"][0]['value'] * 100
    lower_bound = response_json["predictions"][0]['lower_bound'] * 100
    upper_bound = response_json["predictions"][0]['upper_bound'] * 100
    deployedModelId = response_json['deployedModelId']
    modelDisplayName = response_json['modelDisplayName']
    modelVersionId = response_json['modelVersionId']
    return render_template('prediction.html', pred_value = pred_value, lower_bound = lower_bound,
                           upper_bound =upper_bound, deployedModelId=deployedModelId,
                           modelDisplayName = modelDisplayName, modelVersionId = modelVersionId)


class RegistrationForm(Form):
    Gender = TextField('Gender')
    Country_of_Birth = TextField('Country_of_Birth')
    Marital_Status_Key = TextField('Marital_Status_Key')
    Business_Area = TextField('Business_Area')
    Payroll_Area = TextField('Payroll_Area')
    Position = TextField('Position')
    EducationField = TextField('EducationField')
    Institution = TextField('Institution')
    title = TextField('title')


def predict_tabular_classification_sample(
    project: str,
    endpoint_id: str,
    instance_dict: Dict,
    location: str = "us-central1",
    api_endpoint: str = "us-central1-aiplatform.googleapis.com",
):
    # The AI Platform services require regional API endpoints.
    client_options = {"api_endpoint": api_endpoint}
    # Initialize client that will be used to create and send requests.
    # This client only needs to be created once, and can be reused for multiple requests.
    credentials = service_account.Credentials.from_service_account_file('vlba-2-rsd-scenario-80fdce9be1ec.json')
    client = aiplatform.gapic.PredictionServiceClient(client_options=client_options, credentials=credentials)
    # for more info on the instance schema, please use get_model_sample.py
    # and look at the yaml found in instance_schema_uri
    instance = json_format.ParseDict(instance_dict, Value())
    instances = [instance]
    parameters_dict = {}
    parameters = json_format.ParseDict(parameters_dict, Value())
    endpoint = client.endpoint_path(
        project=project, location=location, endpoint=endpoint_id
    )
    response = client.predict(
        endpoint=endpoint, instances=instances, parameters=parameters
    )
    print("response")
    print(" deployed_model_id:", response.deployed_model_id)
    # See gs://google-cloud-aiplatform/schema/predict/prediction/tabular_classification_1.0.0.yaml for the format of the predictions.
    predictions = response.predictions
    for prediction in predictions:
        print(" prediction:", dict(prediction))
    return response



@app.route('/', methods=['GET','POST'])
def register():
    error = ""
    form = RegistrationForm(request.form)
    if request.method == 'POST':
        Gender = request.form['Gender']
        Country_of_Birth = request.form['Country_of_Birth']
        Marital_Status_Key = request.form['Marital_Status_Key']
        Business_Area = request.form['Business_Area']
        Payroll_Area = request.form['Payroll_Area']
        Position = request.form['Position']
        EducationField = request.form['EducationField']
        Institution = request.form['Institution']
        title = request.form['title']

        if len(Gender) == 0 or len(Country_of_Birth) == 0 or len(Marital_Status_Key) == 0 or len(Business_Area) == 0\
                or len(Payroll_Area) == 0 or len(Position) == 0 or len(EducationField) == 0\
                or len(Institution) == 0 or len(title) == 0:
            # Form data failed validation; try again
            error = "Please enter all the fields"
        else:
            # Form data is valid; move along
            #return redirect(url_for('thank_you'))
            return thank_you(Gender, Country_of_Birth, Marital_Status_Key, Business_Area, Payroll_Area, Position
                             , EducationField, Institution, title)





    return render_template('register.html', form=form, message=error)





# def predict_tabular_classification_sample_multiple(
#     project: str,
#     endpoint_id: str,
#     instance_list: List,
#     location: str = "us-central1",
#     api_endpoint: str = "us-central1-aiplatform.googleapis.com",
# ):
#     # The AI Platform services require regional API endpoints.
#     client_options = {"api_endpoint": api_endpoint}
#     # Initialize client that will be used to create and send requests.
#     # This client only needs to be created once, and can be reused for multiple requests.
#     credentials = service_account.Credentials.from_service_account_file('vlba-2-rsd-scenario-80fdce9be1ec.json')
#     client = aiplatform.gapic.PredictionServiceClient(client_options=client_options, credentials=credentials)
#     # for more info on the instance schema, please use get_model_sample.py
#     # and look at the yaml found in instance_schema_uri
#     instances = []
#     for instance_dict in instance_list:
#         instance = json_format.ParseDict(instance_dict, Value())
#         instances.append(instance)
#
#     parameters_dict = {}
#     parameters = json_format.ParseDict(parameters_dict, Value())
#     endpoint = client.endpoint_path(
#         project=project, location=location, endpoint=endpoint_id
#     )
#     response = client.predict(
#         endpoint=endpoint, instances=instances, parameters=parameters
#     )
#     print("response")
#     print(" deployed_model_id:", response.deployed_model_id)
#     # See gs://google-cloud-aiplatform/schema/predict/prediction/tabular_classification_1.0.0.yaml for the format of the predictions.
#     predictions = response.predictions
#     # for prediction in predictions:
#     #     print(" prediction:", dict(prediction))
#     return predictions


def predict_tabular_classification_sample_multiple(
    project: str,
    endpoint_id: str,
    instance_list: List,
    location: str = "us-central1",
    api_endpoint: str = "us-central1-aiplatform.googleapis.com",
):
    # The AI Platform services require regional API endpoints.
    client_options = {"api_endpoint": api_endpoint}
    # Initialize client that will be used to create and send requests.
    # This client only needs to be created once, and can be reused for multiple requests.
    credentials = service_account.Credentials.from_service_account_file('vlba-2-rsd-scenario-80fdce9be1ec.json')
    client = aiplatform.gapic.PredictionServiceClient(client_options=client_options, credentials=credentials)
    # for more info on the instance schema, please use get_model_sample.py
    # and look at the yaml found in instance_schema_uri
    instances = []
    for instance_dict in instance_list:
        instance = json_format.ParseDict(instance_dict, Value())
        instances.append(instance)

    parameters_dict = {}
    parameters = json_format.ParseDict(parameters_dict, Value())
    endpoint = client.endpoint_path(
        project=project, location=location, endpoint=endpoint_id
    )
    response = client.predict(
        endpoint=endpoint, instances=instances, parameters=parameters
    )
    print("response")
    print(" deployed_model_id:", response.deployed_model_id)
    # See gs://google-cloud-aiplatform/schema/predict/prediction/tabular_classification_1.0.0.yaml for the format of the predictions.
    predictions = response.predictions

    values = []
    for prediction in predictions:
        print(" prediction:", dict(prediction))
        values.append(dict(prediction)['value']*100)
    return values


def fetch_data(table):
    print("fetched")
    credentials = service_account.Credentials.from_service_account_file('vlba-2-rsd-scenario-80fdce9be1ec.json')
    project_id = 'vlba-2-rsd-scenario'
    client = bigquery.Client(credentials=credentials, project=project_id)

    query_job = client.query("SELECT * FROM " + project_id + ".rsd_data." + table)

    results = query_job.to_dataframe()
    print("fetched")
    print(results)

    return results


@app.route('/dashboard',  methods=['GET', 'POST'])
def dashboard():

    df = fetch_data("prospective_employee_data")
    print(df.shape)

    # not needed for prediction
    df_without_name = df.drop(columns=['Name', 'Nationality'])
    print(df_without_name.shape)
    df_without_name['Business_Area'] = 'RSD'
    if request.method == 'POST':
        print("new search " + request.form['Business_Area'])
        df_without_name['Business_Area'] = request.form['Business_Area']

    if request.method == 'POST':
        return redirect(url_for('dashboardsearch'), business_area = request.form['Business_Area'])
    instances = df_without_name.to_dict('records')

    # [END aiplatform_predict_tabular_classification_sample]
    success_rate_list = predict_tabular_classification_sample_multiple(
        project="5110117733",
        endpoint_id="2198842935645044736",
        location="us-central1",
        instance_list=instances
    )

    df['success_rate'] = success_rate_list
    final_df = df.sort_values(by=['success_rate'], ascending=False)
    final_df = final_df.head(10)
    print(df)
    return render_template('dashboard.html', tables=[final_df.to_html(classes='data')], titles=df.columns.values)



app.run(host="localhost", port=8000, debug=True)

# See PyCharm help at https://www.jetbrains.com/help/pycharm/
