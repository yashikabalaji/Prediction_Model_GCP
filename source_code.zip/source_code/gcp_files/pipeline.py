from google.cloud import aiplatform
import kfp
from google.cloud import aiplatform
from google_cloud_pipeline_components import aiplatform as gcc_aip
 
from google_cloud_pipeline_components.v1.bigquery import (BigqueryQueryJobOp) 
 
project_id = "vlba-2-rsd-scenario"
pipeline_root_path = "gs://vlba-ml-pipeline-bucket" 
 
# [START aiplatform_sdk_create_and_import_dataset_tabular_bigquery_sample]
def create_and_import_dataset_tabular_bigquery_sample(
   display_name: str,
   project: str,
   bigquery_source: str,
):
 
   ds_op = gcc_aip.TabularDatasetCreateOp(
       display_name=display_name,
       bq_source=bigquery_source,
       project=project,
   )
   print(ds_op.outputs['dataset'])
      
   return ds_op
 
# Define the workflow of the pipeline.
@kfp.dsl.pipeline(
   name="automl-employee-success-rate-training",
   pipeline_root=pipeline_root_path)
def pipeline(project_id: str):
   # The first step of your workflow is a dataset generator.
   ds_op = create_and_import_dataset_tabular_bigquery_sample("rsd_data", project_id, 
            "bq://vlba-2-rsd-scenario.rsd_data.employee_training_data")
   # The second step is a model training component. It takes the dataset
   # outputted from the first step, supplies it as an input argument to the
   # component   
   training_job_run_op = gcc_aip.AutoMLTabularTrainingJobRunOp(
       project=project_id,
       display_name="train_best_model",
       optimization_prediction_type="regression",
       dataset=ds_op.outputs["dataset"],
       model_display_name="automl_model",
       target_column="success_score",
       budget_milli_node_hours=2000,
   )
 
   # The third and fourth step are for deploying the model.
   create_endpoint_op = gcc_aip.EndpointCreateOp(
       project=project_id,
       display_name = "best_trained_model_endpoint",
   )
 
   model_deploy_op = gcc_aip.ModelDeployOp(
       model=training_job_run_op.outputs["model"],
       endpoint=create_endpoint_op.outputs['endpoint'],
       dedicated_resources_machine_type="n1-standard-16",
       dedicated_resources_min_replica_count=1,
       dedicated_resources_max_replica_count=1,
 
   )
 
from kfp.v2 import compiler
compiler.Compiler().compile(
    pipeline_func=pipeline,
    package_path='best_trained_model_pipeline.json'
)
