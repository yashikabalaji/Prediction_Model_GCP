import google.cloud.aiplatform as aip


project_id = "vlba-2-rsd-scenario"
PROJECT_REGION = "us-central1"
pipeline_root_path = "gs://vlba-ml-pipeline-bucket" 

# Before initializing, make sure to set the GOOGLE_APPLICATION_CREDENTIALS
# environment variable to the path of your service account.
aip.init(
    project=project_id,
    location=PROJECT_REGION,
)

# Prepare the pipeline job
job = aip.PipelineJob(
    display_name="automl-employee-success-rate-training",
    template_path="best_trained_model_pipeline.json",
    pipeline_root=pipeline_root_path,
    parameter_values={
        'project_id': project_id
    }
)

job.submit()