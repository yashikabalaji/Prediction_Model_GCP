# Copyright 2020 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# [START aiplatform_predict_tabular_classification_sample]
from typing import Dict, List

from google.cloud import aiplatform
from google.protobuf import json_format
from google.protobuf.struct_pb2 import Value
from google.oauth2 import service_account
from google.cloud import bigquery

def predict_tabular_classification_sample(
    project: str,
    endpoint_id: str,
    instance_list: List,
    location: str = "us-central1",
    api_endpoint: str = "us-central1-aiplatform.googleapis.com",
):
    # The AI Platform services require regional API endpoints.
    client_options = {"api_endpoint": api_endpoint}
    # Initialize client that will be used to create and send requests.
    # This client only needs to be created once, and can be reused for multiple requests.
    credentials = service_account.Credentials.from_service_account_file('vlba-2-rsd-scenario-80fdce9be1ec.json')
    client = aiplatform.gapic.PredictionServiceClient(client_options=client_options, credentials=credentials)
    # for more info on the instance schema, please use get_model_sample.py
    # and look at the yaml found in instance_schema_uri
    instances = []
    for instance_dict in instance_list:
        instance = json_format.ParseDict(instance_dict, Value())
        instances.append(instance)

    parameters_dict = {}
    parameters = json_format.ParseDict(parameters_dict, Value())
    endpoint = client.endpoint_path(
        project=project, location=location, endpoint=endpoint_id
    )
    response = client.predict(
        endpoint=endpoint, instances=instances, parameters=parameters
    )
    print("response")
    print(" deployed_model_id:", response.deployed_model_id)
    # See gs://google-cloud-aiplatform/schema/predict/prediction/tabular_classification_1.0.0.yaml for the format of the predictions.
    predictions = response.predictions

    values = []
    for prediction in predictions:
        print(" prediction:", dict(prediction))
        values.append(dict(prediction)['value']*100)
    return values

def fetch_data(table):
	credentials = service_account.Credentials.from_service_account_file('vlba-2-rsd-scenario-80fdce9be1ec.json')
	project_id = 'vlba-2-rsd-scenario'
	client = bigquery.Client(credentials= credentials,project=project_id)

	query_job = client.query("SELECT * FROM "+project_id+".rsd_data."+table)

	results = query_job.to_dataframe() 
	
	return results

def main():
    # fetch data from bigquery table
    df = fetch_data("prospective_employee_data")
    print(df.shape)

    # not needed for prediction
    df_without_name = df.drop(columns=['Name', 'Nationality'])
    print(df_without_name.shape)

    # input from UI like RSD, MS, MPD, CCR
    df_without_name['Business_Area'] = 'MS'

    instances = df_without_name.to_dict('records')

    # [END aiplatform_predict_tabular_classification_sample]
    success_rate_list = predict_tabular_classification_sample(
        project="5110117733",
        endpoint_id="2198842935645044736",
        location="us-central1",
        instance_list=instances
    )

    df['success_rate'] = success_rate_list
    final_df = df.sort_values(by=['success_rate'], ascending=False)
    print(final_df.head(10))


main()
