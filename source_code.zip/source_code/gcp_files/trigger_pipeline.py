import base64
import json
import os

from google.cloud import pubsub_v1
from unittest.mock import MagicMock

# set this environment variable
PROJECT_ID = "vlba-2-rsd-scenario"
pipeline_spec_path = "gs://vlba-ml-pipeline-bucket/best_trained_model_pipeline.json"

# Instantiates a Pub/Sub client
publisher = pubsub_v1.PublisherClient()

# Publishes a message to a Cloud Pub/Sub topic.
def publish(request):
    request_json = request.get_json(silent=True)

    topic_name = request_json.get("topic")
    message = request_json.get("message")

    if not topic_name or not message:
        return ('Missing "topic" and/or "message" parameter.', 400)

    print(f"Publishing message to topic {topic_name}")

    # References an existing topic
    topic_path = publisher.topic_path(PROJECT_ID, topic_name)

    message_json = json.dumps(
        {
            "pipeline_spec_uri": pipeline_spec_path,
            "parameter_values":{
                'project_id': PROJECT_ID
            }
        }
    )
    message_bytes = message_json.encode("utf-8")

    # Publishes a message
    try:
        publish_future = publisher.publish(topic_path, data=message_bytes)
        publish_future.result()  # Verify the publish succeeded
        return "Message published."
    except Exception as e:
        print(e)
        return (e, 500)


def test_functions_pubsub_publish_should_publish_message():
    request = MagicMock()
    request.get_json.return_value = {"topic": "topic-ml-pipeline", "message": "hello world!!"}

    response = publish(request)
    print(response)
    assert response == "Message published."

test_functions_pubsub_publish_should_publish_message()